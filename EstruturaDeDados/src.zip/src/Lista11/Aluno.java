package Lista11;

public class Aluno {

    private int numMat;
    private String nome;

    public Aluno(int numMat) {
        this.numMat = numMat;
    }

    public int getNumMat() {
        return numMat;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }
}
